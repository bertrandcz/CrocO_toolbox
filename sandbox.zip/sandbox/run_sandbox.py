from CrocoParallel import CrocoParallel
from crocO import set_options
import os

#my_root_sandbox = 'Here the path to your CrocO sandbox folder (with / at the end)'
#my_toolbox_py = 'Here the path to your crocO.py in the toolbox folder'
my_root_sandbox = '/home/fructusm/Travail_CrocO_sandbox/'
my_toolbox_py ='/home/fructusm/git/CrocO_toolbox/crocO.py'
vconf = 'geometry'  # geometry of the experiment
ppvars = 'DEP,SWE'  # output variables
nmembers = 3  # ensemble size
date_begin = '2013080106'
date_end = '2014063006'
escroc = 'E1notartes'
os.environ['VORTEXPATH'] = my_root_sandbox + 'sandbox/'
os.environ['CROCOPATH'] = os.environ['VORTEXPATH']
xpid = 'testAssim'  # dir for the specific experiment within exe_dir
arch_path = os.environ['VORTEXPATH'] + 'arch_' + xpid  # archiving path for the experiment )(different from xpid)

#################
args = [
    my_toolbox_py,
    '-n', os.environ['VORTEXPATH'] + '/MOTHER_NAMELIST.nam',
    '-f', os.environ['VORTEXPATH'] + 'safran/' + vconf + '/forcing_folder',
    '--spinup', os.environ['VORTEXPATH'] + 's2m/' + vconf + '/spinup/',
    '-b', date_begin,
    '-e', date_end,
    '--vconf', vconf,
    '--nmembers', str(nmembers),
    '--nforcing', str(3),
    '--escroc', escroc,
    '--xpid', 'testAssim',  # exe directory
    '--arch', arch_path,
    '--todo','parallel',  # this is mandatory for you
    '--pf','global',  # likewise
    '--ppvars', 'DEP',
    '--vars', 'DEP',  # this is dummy
    '-d', 'all',  # this is dummy
    '--sensor', 'sensor',

]
options = set_options(args,pathConf=os.environ['VORTEXPATH'] + 'conf.ini', useVortex = False)
run = CrocoParallel(options)
run.run(cleanup=False)

